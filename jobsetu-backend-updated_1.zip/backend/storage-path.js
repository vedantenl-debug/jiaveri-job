// storage-path.js — Render वर Persistent Disk जोडलेला असेल (mountPath: /data) तर
// database व resumes तिथे कायमस्वरूपी साठवतो — सर्व्हर restart झाला तरी डेटा टिकतो.
// Disk नसेल (local computer वर चालवताना) तर नेहमीप्रमाणे याच backend फोल्डरमध्ये ठेवतो.

const fs = require('fs');
const path = require('path');

const DATA_DIR = fs.existsSync('/data') ? '/data' : __dirname;
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

module.exports = { DATA_DIR, UPLOADS_DIR };
